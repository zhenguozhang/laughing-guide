#pragma once
#include"pch.h"
#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>

using namespace std;
extern ifstream fin;
extern int * route_number;