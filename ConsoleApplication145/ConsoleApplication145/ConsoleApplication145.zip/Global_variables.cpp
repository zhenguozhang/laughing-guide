#include"pch.h"
#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>

using namespace std;
ifstream fin;
int * route_number;